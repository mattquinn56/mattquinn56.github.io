To start, run marching-cubes.exe.
Hold down right-click to look around, and use WASD to move the camera.